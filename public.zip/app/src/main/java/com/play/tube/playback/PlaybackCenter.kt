package com.play.tube.playback

import android.content.ComponentName
import android.content.Context
import android.net.Uri
import androidx.annotation.OptIn
import androidx.core.content.ContextCompat
import androidx.media3.common.AudioAttributes
import androidx.media3.common.C
import androidx.media3.common.ForwardingPlayer
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.common.util.UnstableApi
import androidx.media3.datasource.DataSpec
import androidx.media3.datasource.DefaultDataSource
import androidx.media3.datasource.DefaultHttpDataSource
import androidx.media3.datasource.ResolvingDataSource
import androidx.media3.exoplayer.DefaultRenderersFactory
import androidx.media3.exoplayer.DefaultLoadControl
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory
import androidx.media3.exoplayer.source.MediaSource
import androidx.media3.exoplayer.source.MergingMediaSource
import androidx.media3.exoplayer.source.ProgressiveMediaSource
import android.os.SystemClock
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import androidx.media3.ui.PlayerView
import com.play.tube.data.DownloadRecord
import com.play.tube.data.LocalStore
import com.play.tube.data.LiveFilter
import com.play.tube.data.RecommendEngine
import com.play.tube.data.VideoEntry
import com.play.tube.data.YtRepository
import com.play.tube.download.DownloadCenter
import com.play.tube.net.OkHttpDownloader
import com.play.tube.net.ParallelRangeDataSource
import com.play.tube.util.AppPrefs
import com.play.tube.util.Net
import com.google.common.util.concurrent.ListenableFuture
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.runBlocking
import org.schabi.newpipe.extractor.stream.AudioStream
import org.schabi.newpipe.extractor.stream.AudioTrackType
import org.schabi.newpipe.extractor.stream.StreamInfo
import org.schabi.newpipe.extractor.stream.StreamInfoItem
import org.schabi.newpipe.extractor.stream.VideoStream
import java.io.File
import java.io.IOException
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.atomic.AtomicLong

/**
 * Thrown wherever a resolved stream turns out to be a live broadcast, which
 * PlayTube intentionally never plays. Kept as its own type (rather than a
 * magic "LIVE_CONTENT" string inside a generic exception) so callers can
 * detect it with `is LiveContentException` instead of substring-matching an
 * error message, which silently stops working if the message ever changes.
 */
class LiveContentException :
    IOException("This is a live stream, which PlayTube doesn't support playing.")

/** Best-effort height: itag height or parsed from the resolution string ("1080p60"). */
fun VideoStream.effectiveHeight(): Int =
    if (height > 0) height else StreamCatalog.resolutionHeight(resolution)

/** One item in the play queue (resolved lazily when it starts playing). */
data class QueueEntry(
    val url: String,
    val title: String,
    val uploader: String,
    val thumbnailUrl: String,
    val durationSec: Long,
    val isMusic: Boolean = false
)

/** A group of audio streams that share the same dubbing language. */
data class AudioTrackGroup(
    val id: String,
    val label: String,
    val isOriginal: Boolean,
    val streams: List<AudioStream>
) {
    val best: AudioStream? get() = streams.filter { it.isUrl }.maxByOrNull { it.averageBitrate }
}

data class Chapter(val title: String, val startSec: Int)

/** One selectable caption track (one per language, manual preferred over auto). */
data class SubtitleOption(val lang: String, val label: String, val url: String, val mime: String)

/** Cleaned-up stream catalogue for the currently loaded item. */
class StreamCatalog(info: StreamInfo) {

    val name: String = info.name ?: ""
    val uploaderUrl: String = info.uploaderUrl ?: ""
    val uploaderName: String = info.uploaderName ?: ""
    val uploaderAvatarUrl: String = info.uploaderAvatars.maxByOrNull { it.height }?.url.orEmpty()
    val viewCount: Long = info.viewCount
    val durationSec: Long = info.duration

    /** Video description (HTML for YouTube) — folded/unfolded on the watch page. */
    val description: String = info.description?.content.orEmpty()
    val descriptionIsHtml: Boolean =
        info.description?.type == org.schabi.newpipe.extractor.stream.Description.HTML

    /** Relative upload date, e.g. "3 days ago" (empty when unknown). */
    val uploadDateText: String =
        com.play.tube.util.Formatters.formatRelativeTime(info.textualUploadDate)
    val likeCount: Long = info.likeCount

    /** Video-only adaptive streams (higher qualities), distinct heights, best first. */
    val videoOnly: List<VideoStream> = info.videoOnlyStreams
        .filter { it.isUrl && it.effectiveHeight() > 0 }
        .distinctBy { it.effectiveHeight() }
        .sortedByDescending { it.effectiveHeight() }

    /**
     * Every video-only stream (all codecs / fps variants, not de-duplicated by
     * height): the raw material for the adaptive DASH start ([DashSources]).
     */
    val allVideoOnly: List<VideoStream> = info.videoOnlyStreams
        .filter { it.isUrl && it.effectiveHeight() > 0 }

    /** Progressive (muxed) streams, fallback only. */
    val muxed: List<VideoStream> = info.videoStreams
        .filter { it.isUrl && it.effectiveHeight() > 0 }
        .distinctBy { it.effectiveHeight() }
        .sortedByDescending { it.effectiveHeight() }

    /** Audio streams grouped into dubbing languages. */
    val audioTracks: List<AudioTrackGroup> = info.audioStreams
        .filter { it.isUrl }
        .groupBy { it.audioTrackId ?: it.audioTrackName ?: "default" }
        .map { (id, streams) ->
            val first = streams.first()
            AudioTrackGroup(
                id = id,
                label = first.audioTrackName?.takeIf { it.isNotBlank() }
                    ?: if (id == "default") "Default" else id,
                isOriginal = first.audioTrackType == AudioTrackType.ORIGINAL,
                streams = streams.sortedByDescending { it.averageBitrate }
            )
        }
        .sortedWith(compareByDescending<AudioTrackGroup> { it.isOriginal }.thenBy { it.label })

    /** Chapters (title + start seconds) from the video description. */
    val chapters: List<Chapter> = runCatching {
        info.streamSegments.orEmpty()
            .filter { it.startTimeSeconds >= 0 && !it.title.isNullOrBlank() }
            .map { Chapter(it.title.orEmpty(), it.startTimeSeconds) }
            .sortedBy { it.startSec }
    }.getOrDefault(emptyList())

    /** Storyboard sprite sheets for the seek-bar thumbnail preview (best size ~ 160px wide). */
    val previewFrames: org.schabi.newpipe.extractor.stream.Frameset? = runCatching {
        val all = info.previewFrames.orEmpty().filter { it.urls.isNotEmpty() && it.durationPerFrame > 0 }
        all.sortedBy { it.frameWidth }.firstOrNull { it.frameWidth >= 160 } ?: all.maxByOrNull { it.frameWidth }
    }.getOrNull()

    /** Caption tracks offered in the settings sheet. */
    val subtitles: List<SubtitleOption> = runCatching {
        info.subtitles.orEmpty()
            .filter { it.isUrl && !it.languageTag.isNullOrBlank() }
            .mapNotNull { st ->
                val mime = when (st.format?.mimeType) {
                    "text/vtt" -> androidx.media3.common.MimeTypes.TEXT_VTT
                    "application/ttml+xml" -> androidx.media3.common.MimeTypes.APPLICATION_TTML
                    "text/srt", "application/x-subrip" -> androidx.media3.common.MimeTypes.APPLICATION_SUBRIP
                    else -> return@mapNotNull null
                }
                val base = st.displayLanguageName?.takeIf { it.isNotBlank() } ?: st.languageTag
                SubtitleOption(
                    lang = st.languageTag,
                    label = if (st.isAutoGenerated) "$base (auto)" else base,
                    url = st.content,
                    mime = mime
                ) to st.isAutoGenerated
            }
            .sortedBy { it.second }
            .map { it.first }
            .distinctBy { it.lang }
            .sortedBy { it.label }
            .take(40)
    }.getOrDefault(emptyList())

    /** Related videos for the watch page (already live-filtered). */
    val related: List<StreamInfoItem> = LiveFilter.sanitize(info.relatedItems)

    val hasVideo: Boolean get() = videoOnly.isNotEmpty() || muxed.isNotEmpty()

    companion object {
        fun resolutionHeight(resolution: String): Int =
            Regex("(\\d{3,4})").find(resolution)?.groupValues?.get(1)?.toIntOrNull() ?: 0
    }

    fun qualityLabel(v: VideoStream): String {
        val height = v.effectiveHeight()
        val fps = if (v.fps > 30 && v.fps < 100) "${v.fps}fps" else ""
        val tag = if (v.isVideoOnly) " (video only)" else ""
        return listOf(height.toString() + "p", fps).filter { it.isNotBlank() }.joinToString(" ") + tag
    }
}

/**
 * App-wide playback engine. Owns the single ExoPlayer instance that the
 * watch page, the mini player, the music screen and the media notification
 * all attach to, so playback survives screen changes and app close.
 *
 * Video mode uses a single merged source. Music mode builds a real
 * playlist whose items are resolved on demand, so the media notification
 * gets native previous / next / seek controls.
 */
@OptIn(UnstableApi::class)
object PlaybackCenter {

    enum class Mode { NONE, VIDEO, AUDIO }

    interface Listener {
        fun onItemChanged(entry: QueueEntry?) {}
        fun onResolvingChanged(isResolving: Boolean) {}
        fun onCatalogReady() {}
        fun onPlaybackStateChanged(isPlaying: Boolean) {}
        fun onQueueChanged() {}
        fun onSleepTimerChanged() {}
        fun onSleepTimerExpired() {}
        fun onVideoFrameRendered() {}
        fun onError(message: String) {}

        /** A resolved item turned out to be live content — see [LiveContentException]. */
        fun onLiveContentBlocked() {}
        fun onFavoriteChanged(url: String, isFavorite: Boolean) {}
        fun onAudioOnlyChanged(audioOnly: Boolean) {}

        /** Short user-facing hint ("switched to the default audio track", …). */
        fun onNotice(message: String) {}
    }

    lateinit var appContext: Context
        private set

    val listeners = mutableListOf<Listener>()

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)

    // Radio sizing: first batch, refill threshold / batch, and the minimum
    // number of upcoming songs before the artist-search top-up kicks in.
    private const val RADIO_FIRST_BATCH = 30
    private const val RADIO_BATCH = 20
    private const val RADIO_REFILL_BELOW = 10
    private const val RADIO_MIN_UPCOMING = 15
    private var playerRef: ExoPlayer? = null
    private val sleepTimer = SleepTimerState()
    private var sleepTimerJob: Job? = null
    private val timerHandler = android.os.Handler(android.os.Looper.getMainLooper())
    private val timerAlarm = android.app.AlarmManager.OnAlarmListener { checkSleepTimer() }
    val sleepTimerMode: SleepTimerState.Mode get() = sleepTimer.mode
    var sleepTimerMinutes: Int = 0
        private set
    val sleepTimerRemainingMs: Long? get() = sleepTimer.remainingMs(SystemClock.elapsedRealtime())

    /** Shared timer survives page collapse, mode changes, pause and background playback. */
    fun setSleepTimer(minutes: Int) {
        require(minutes in listOf(10, 15, 20, 30, 45, 60))
        clearSleepTimer()
        sleepTimer.setDuration(minutes, SystemClock.elapsedRealtime())
        sleepTimerMinutes = minutes
        // Listener alarms need no exact-alarm permission and wake the live playback process.
        // The monotonic coroutine is also retained as a foreground/service fallback.
        try {
            val alarms = appContext.getSystemService(Context.ALARM_SERVICE) as android.app.AlarmManager
            alarms.setExact(android.app.AlarmManager.ELAPSED_REALTIME_WAKEUP,
                sleepTimer.deadlineMs!!, "PlayTube sleep timer", timerAlarm, timerHandler)
        } catch (_: SecurityException) { /* OEM restriction: service ticker still checks. */ }
        sleepTimerJob = scope.launch {
            while (isActive && sleepTimer.mode == SleepTimerState.Mode.DURATION) {
                if (checkSleepTimer()) break
                delay(minOf(sleepTimerRemainingMs ?: 1000L, 1000L).coerceAtLeast(1L))
            }
        }
        notify { it.onSleepTimerChanged() }
    }

    fun setSleepTimerEndOfItem() {
        if (!hasMedia) return
        clearSleepTimer()
        sleepTimer.setEndOfItem(currentEntry?.url)
        // Pause before the native music playlist can start its next item.
        applyMusicAutoplay()
        notify { it.onSleepTimerChanged() }
        if (playerRef?.playbackState == Player.STATE_ENDED) expireSleepTimer()
    }

    fun clearSleepTimer() {
        sleepTimerJob?.cancel()
        sleepTimerJob = null
        if (this::appContext.isInitialized) {
            (appContext.getSystemService(Context.ALARM_SERVICE) as android.app.AlarmManager).cancel(timerAlarm)
        }
        sleepTimer.clear()
        sleepTimerMinutes = 0
        applyMusicAutoplay()
        notify { it.onSleepTimerChanged() }
    }

    private fun checkSleepTimer(): Boolean {
        if (!sleepTimer.isExpired(SystemClock.elapsedRealtime())) return false
        expireSleepTimer()
        return true
    }

    private fun expireSleepTimer() {
        // Cancel resolving/watchdogs as well: a pending network result must not restart playback.
        stopPlayback()
        notify { it.onSleepTimerExpired() }
    }

    private var resolveJob: Job? = null
    private val pendingVideo = PendingPlaybackRequest()
    private val videoRequestPending: Boolean
        get() = mode == Mode.VIDEO && pendingVideo.active

    // ----- Startup watchdog (auto quality downshift) -----

    /**
     * Big-video insurance. Bigger streams are exactly the ones whose bitrate
     * outruns a slow / throttled connection, so "stuck on the loading spinner
     * at the start, recovers after a while" was the steady state whenever the
     * network could not feed 720p+. This watchdog watches the first seconds of
     * every video: if the first frame does not appear in time, or the video
     * stalls right after starting, it drops ONE quality tier and rebuilds the
     * source (keeping the position mid-play) until playback actually flows.
     */
    private var frameWatchJob: Job? = null
    private var videoFrameSeen = false
    private var frameRecoveryStep = 0
    private var watchdogJob: Job? = null
    private var watchdogDownshifts = 0

    /**
     * Height the startup watchdog dropped the CURRENT video to. Kept apart
     * from [selectedHeight] (the user's own pick) on purpose: a slow start
     * on one video must not silently cap every following video — and, with
     * playlists, the whole rest of the list — to the lower quality. Cleared
     * whenever a new video starts resolving or the user picks a quality.
     */
    private var downshiftHeight: Int? = null

    // ----- Adaptive (DASH) start -----

    /** The source currently on the player is the adaptive one (see [DashSources]). */
    private var dashActive = false

    /** The adaptive start failed / was too slow for THIS video: use plain progressive. */
    private var dashBlocked = false

    /** When the current source was handed to the player (first-frame timing log). */
    private var sourceAppliedAt = 0L

    /**
     * Watchdog: ms without a first frame before dropping one quality tier.
     * 10s (was 5s): a cold start pays one-off DNS / TCP / TLS / CDN costs
     * that a warm re-open (manual quality switch, seek) does not, so 5s
     * downshifted streams that would have started fine a moment later.
     */
    private val STARTUP_LIMIT_MS = 10_000L

    /** Watchdog: ms of a post-start stall before dropping one quality tier. */
    private val STALL_LIMIT_MS = 4_000L

    /** Items of the music playlist that have not been resolved yet. */
    private val pendingMusic = ConcurrentHashMap<String, QueueEntry>()
    private val musicItemId = AtomicLong(0L)

    /** Already-resolved audio URLs for music queue entries (entry.url -> Uri). */
    private val musicUriCache = ConcurrentHashMap<String, Uri>()

    private var prefetchJob: Job? = null

    /**
     * App-side controller connection to PlaybackService. Media3 only shows
     * (and keeps updating) the media notification while a MediaController is
     * connected to the MediaSessionService, so the app itself must hold one
     * open. Created on first playback, kept for the lifetime of the process.
     */
    private var controllerFuture: ListenableFuture<MediaController>? = null

    @Volatile var mode: Mode = Mode.NONE
        private set(value) {
            field = value
            applyRepeatMode()
        }

    /** "Loop video" from the player settings: only ever applies in video mode. */
    var videoLoop: Boolean = false
        private set

    fun setVideoLoop(on: Boolean) {
        videoLoop = on
        applyRepeatMode()
    }

    /** Music player: shuffle and repeat (off / all / one). */
    var musicShuffle: Boolean = false
        private set
    var musicRepeat: Int = Player.REPEAT_MODE_OFF
        private set

    fun toggleShuffle() { musicShuffle = !musicShuffle; applyRepeatMode() }

    fun cycleRepeat() {
        musicRepeat = when (musicRepeat) {
            Player.REPEAT_MODE_OFF -> Player.REPEAT_MODE_ALL
            Player.REPEAT_MODE_ALL -> Player.REPEAT_MODE_ONE
            else -> Player.REPEAT_MODE_OFF
        }
        applyRepeatMode()
    }

    private fun applyRepeatMode() {
        val p = playerRef ?: return
        if (mode == Mode.AUDIO) {
            p.shuffleModeEnabled = musicShuffle
            p.repeatMode = musicRepeat
        } else {
            p.shuffleModeEnabled = false
            p.repeatMode = if (videoLoop && mode == Mode.VIDEO) Player.REPEAT_MODE_ONE else Player.REPEAT_MODE_OFF
        }
    }

    /** "Skip silence" from the player settings. */
    fun setSkipSilence(on: Boolean) {
        playerRef?.setSkipSilenceEnabled(on)
    }
    private val pipSession = PipSessionState<PlayerView>()
    val inPip: Boolean get() = pipSession.active

    fun setPipState(view: PlayerView, active: Boolean, onClose: () -> Unit = {}) {
        if (active) pipSession.claim(view, onClose) else pipSession.release(view)
    }

    /** Explicit playback/page replacement only; automatic queue advance keeps PiP alive. */
    fun closePreviousPip() = pipSession.close()
    @Volatile var audioOnlyMode: Boolean = false
        private set

    val queue = mutableListOf<QueueEntry>()
    var queueIndex: Int = -1
        private set
    var radioMode: Boolean = false
        private set

    /**
     * True while the video queue is a fixed playlist ("Play all" or a video
     * tapped inside a playlist): the queue is exactly the playlist — no
     * related videos get appended — the next item always follows the
     * current one, and an unplayable item is skipped instead of stopping.
     */
    @Volatile var playlistMode: Boolean = false
        private set

    /** True while an item's streams are being resolved (spinner state for late listeners). */
    @Volatile var isResolving: Boolean = false
        private set
    private var usedFallback = false

    var catalog: StreamCatalog? = null
        private set

    /** User selections that survive quality/track switches. */
    var selectedAudioTrackId: String? = null
        private set
    private var selectedHeight: Int? = null

    /** Set when the user explicitly picked "Auto" in the gear menu. */
    private var autoPicked = false

    val selectedQualityHeight: Int? get() = selectedHeight

    /**
     * The quality actually in effect for [c]: an explicit gear-menu pick,
     * otherwise the default-video-quality from settings (what [videoForSelection]
     * really plays). Used by the gear menu so a settings default like 720p
     * shows up as "720p" instead of "Auto".
     */
    fun effectiveSelectedHeight(c: StreamCatalog): Int? {
        downshiftHeight?.let { return it }
        selectedHeight?.let { return it }
        if (autoPicked) return null
        val default = AppPrefs.defaultVideoHeightNow(appContext)
        if (default <= 0) return null
        val candidates = c.videoOnly.ifEmpty { c.muxed }
        return candidates.filter { it.effectiveHeight() <= default }
            .maxByOrNull { it.effectiveHeight() }?.effectiveHeight()
            ?: candidates.minByOrNull { it.effectiveHeight() }?.effectiveHeight()
    }

    val selectedAudioTrackLabel: String?
        get() = selectedAudioTrackId?.let { id ->
            catalog?.audioTracks?.firstOrNull { it.id == id }?.label
        }

    val currentEntry: QueueEntry? get() = queue.getOrNull(queueIndex)
    val hasMedia: Boolean get() = currentEntry != null

    /** Current playback speed in effect. */
    var playbackSpeed: Float = 1.0f
        private set

    // ----- Lifecycle -----

    fun init(context: Context) {
        if (this::appContext.isInitialized) return
        appContext = context.applicationContext
    }

    val player: ExoPlayer
        get() {
            check(this::appContext.isInitialized) { "PlaybackCenter.init() not called" }
            return playerRef ?: ExoPlayer.Builder(appContext, DefaultRenderersFactory(appContext).setEnableDecoderFallback(true))
                // IMPORTANT: player.setMediaItems() (music playlist!) builds
                // its MediaSources through this factory. Without it the
                // player falls back to its own default data source chain,
                // which cannot resolve the virtual playtube:// queue URIs:
                // every song fails with "MalformedURLException: unknown
                // protocol: playtube" and playback skips to the next track
                // (which fails the same way).
                .setMediaSourceFactory(DefaultMediaSourceFactory(dataSourceFactory))
                // Fast first frame WITHOUT the endless startup spinner on big
                // videos: the start cushion only gates how much media must be
                // buffered before playback begins, and a fat cushion (5s of a
                // 720p+ stream is megabytes) on a slow-ramping connection kept
                // the player "stuck" on the loading spinner for ages. 1s gets
                // the first frame on screen fast; the STARTUP WATCHDOG below
                // then watches the connection and auto-drops the quality when
                // bandwidth can't keep up (stalls used to be papered over with
                // a big cushion — now they actually get fixed).
                .setLoadControl(
                    DefaultLoadControl.Builder()
                        // Data-friendly, YouTube-like cushion: enough to ride out
                        // a bad moment, but never racing minutes ahead of what
                        // is watched (that data is wasted whenever the viewer
                        // skips, seeks or leaves). Loading restarts below 20 s.
                        .setBufferDurationsMs(
                            /* minBufferMs = */ 20_000,
                            /* maxBufferMs = */ 45_000,
                            /* bufferForPlaybackMs = */ 1_000,
                            /* bufferForPlaybackAfterRebufferMs = */ 4_000
                        )
                        .setPrioritizeTimeOverSizeThresholds(true)
                        .setBackBuffer(/* backBufferDurationMs = */ 15_000, /* retainBackBufferFromKeyframe = */ true)
                        .build()
                )
                .setAudioAttributes(
                    AudioAttributes.Builder()
                        .setUsage(C.USAGE_MEDIA)
                        .setContentType(C.AUDIO_CONTENT_TYPE_MOVIE)
                        .build(),
                    true
                )
                .setHandleAudioBecomingNoisy(true)
                .setWakeMode(C.WAKE_MODE_NETWORK)
                .build()
                .also { built ->
                    playerRef = built
                    built.setSkipSilenceEnabled(AppPrefs.skipSilence)
                    built.addListener(playerListener)
                }
        }

    /** Stable facade for the media session and in-app player controls. */
    val sessionPlayer: Player
        get() {
            val raw = player
            return forwardingPlayer?.takeIf { forwardingFor === raw }
                ?: QueueForwardingPlayer(raw).also {
                    forwardingPlayer = it
                    forwardingFor = raw
                }
        }

    private val playerListener = object : Player.Listener {
        override fun onIsPlayingChanged(isPlaying: Boolean) {
            notify { it.onPlaybackStateChanged(isPlaying) }
        }

        override fun onPlayWhenReadyChanged(playWhenReady: Boolean, reason: Int) {
            if (!playWhenReady && reason == Player.PLAY_WHEN_READY_CHANGE_REASON_END_OF_MEDIA_ITEM &&
                sleepTimer.shouldStopAtEnd(currentEntry?.url)) {
                expireSleepTimer()
                return
            }
            notify { it.onPlaybackStateChanged(isPlaying) }
        }

        override fun onPlaybackStateChanged(playbackState: Int) {
            if (playbackState == Player.STATE_ENDED && sleepTimer.shouldStopAtEnd(currentEntry?.url)) {
                expireSleepTimer()
                return
            }
            notify { it.onPlaybackStateChanged(isPlaying) }
            // A playlist always continues to its next video (like YouTube);
            // the autoplay setting only governs the related-videos queue.
            if (!videoRequestPending && playbackState == Player.STATE_ENDED && mode == Mode.VIDEO &&
                (playlistMode || localVideoRecords != null || AppPrefs.videoAutoplayNext)
            ) {
                // The watch page may show an "Up next in 5" countdown first.
                if (autoplayInterceptor?.invoke() != true) advance()
            }
        }

        override fun onMediaItemTransition(mediaItem: MediaItem?, reason: Int) {
            if (mode != Mode.AUDIO) return
            if (sleepTimer.shouldStopOnTransition(currentEntry?.url,
                    reason == Player.MEDIA_ITEM_TRANSITION_REASON_AUTO || reason == Player.MEDIA_ITEM_TRANSITION_REASON_REPEAT)) {
                expireSleepTimer()
                return
            }
            val index = playerRef?.currentMediaItemIndex ?: return
            if (index < 0 || index >= queue.size) return
            queueIndex = index
            currentEntry?.let { entry ->
                notify { it.onItemChanged(entry) }
                if (!entry.url.startsWith("file://")) {
                    resolveCatalog(entry)
                }
            }
            // Resolve the next songs in the background so transitions are instant.
            prefetchAhead()
        }

        override fun onPlayerError(error: PlaybackException) {
            // A paused outgoing source can still fail while the next URL resolves.
            if (!videoRequestPending) onPlayerFailed(error)
        }

        override fun onTracksChanged(tracks: androidx.media3.common.Tracks) {
            android.util.Log.i("PlayTubeVideo", "tracks videoSelected=${tracks.isTypeSelected(C.TRACK_TYPE_VIDEO)} videoSupported=${tracks.isTypeSupported(C.TRACK_TYPE_VIDEO)} adaptive=$dashActive")
        }

        override fun onVideoSizeChanged(videoSize: androidx.media3.common.VideoSize) {
            android.util.Log.i("PlayTubeVideo", "size=${videoSize.width}x${videoSize.height}")
        }

        override fun onRenderedFirstFrame() {
            videoFrameSeen = true
            frameWatchJob?.cancel()
            notify { it.onVideoFrameRendered() }
            if (mode != Mode.VIDEO || sourceAppliedAt == 0L) return
            val ms = SystemClock.elapsedRealtime() - sourceAppliedAt
            android.util.Log.i("PlayTubeStartup", "first frame after ${ms}ms (adaptive=$dashActive)")
            sourceAppliedAt = 0L
        }
    }

    fun addListener(listener: Listener) {
        listeners.add(listener)
    }

    fun removeListener(listener: Listener) {
        listeners.remove(listener)
    }

    private fun notify(block: (Listener) -> Unit) {
        // An explicit new item cancels only end-of-item; timed countdown spans the queue.
        if (sleepTimer.mode == SleepTimerState.Mode.END_OF_ITEM &&
            !sleepTimer.shouldStopAtEnd(currentEntry?.url)) {
            clearSleepTimer()
        }
        forwardingPlayer?.refreshSessionState()
        val snapshot = listeners.toList()
        snapshot.forEach(block)
    }

    private fun ensureService() {
        if (controllerFuture != null) return
        try {
            // A plain startService() is NOT enough: Media3 wires the session
            // player into its notification manager inside addSession(),
            // which only runs when a controller connects (onGetSession).
            // Without this connection background music keeps playing in the
            // app process but no notification - and so no shade / lockscreen
            // controls - ever appears.
            val token =
                SessionToken(appContext, ComponentName(appContext, PlaybackService::class.java))
            val future = MediaController.Builder(appContext, token).buildAsync()
            controllerFuture = future
            // If connecting failed for good, allow another try on the next
            // playback instead of staying silent forever.
            future.addListener(
                {
                    try {
                        future.get()
                    } catch (_: Exception) {
                        controllerFuture = null
                    }
                },
                ContextCompat.getMainExecutor(appContext)
            )
        } catch (_: Exception) {
            // e.g. binding not allowed right now: retried on next playback.
        }
    }

    // ----- Data saving while the app is out of sight -----

    private var appVisible = true

    /**
     * Called by the app when it goes to / comes back from the background.
     * While nobody can see the picture the video track is switched off, so
     * only the sound is downloaded (like YouTube Music in the background):
     * a video played with the screen off or in another app costs a fraction
     * of the data. The picture resumes the moment the app returns.
     */
    fun setAppVisible(visible: Boolean) {
        if (appVisible == visible) return
        appVisible = visible
        val p = playerRef ?: return
        if (mode != Mode.VIDEO) return
        p.trackSelectionParameters = p.trackSelectionParameters.buildUpon()
            .setTrackTypeDisabled(C.TRACK_TYPE_VIDEO, !visible)
            .build()
    }

    /** Kills the current playback instantly so sounds never overlap. */
    private fun stopPlayerNow() {
        pendingVideo.cancel()
        retainedVideoSourceForAudio = false
        playerRef?.run {
            stop()
            clearMediaItems()
        }
    }

    // ----- Commands -----

    /** Starts a video (watch page). Builds a YouTube-like autoplay queue. */
    fun playVideo(entry: QueueEntry, extraQueue: List<QueueEntry> = emptyList()) {
        initFromApp()
        closePreviousPip()
        stopPlayerNow()
        subtitleLang = null
        videoLoop = false
        mode = Mode.VIDEO
        radioMode = false
        playlistMode = false
        audioOnlyMode = false
        setQueue(listOf(entry) + extraQueue, 0)
        resolveCurrent()
    }

    /**
     * Plays a fixed video playlist starting at [startIndex]. The whole list
     * is the queue (previous / next work across it) and every video that
     * finishes hands over to the next one; nothing else is mixed in.
     * Downloaded videos in the list play from disk (offline-friendly).
     */
    fun playPlaylist(entries: List<QueueEntry>, startIndex: Int = 0) {
        initFromApp()
        if (entries.isEmpty()) return
        closePreviousPip()
        stopPlayerNow()
        subtitleLang = null
        mode = Mode.VIDEO
        radioMode = false
        playlistMode = true
        audioOnlyMode = false
        setQueue(entries, startIndex.coerceIn(0, entries.size - 1))
        resolveCurrent()
    }

    /**
     * Starts a song (optionally as an endless radio of related tracks).
     */
    fun playMusic(entry: QueueEntry, radio: Boolean) {
        playMusicQueue(listOf(entry), 0, allowRadio = radio)
    }

    /**
     * Starts a fixed music playlist (favorites, downloads, …): exactly
     * these songs play one after another — nothing else is ever mixed in.
     */
    fun playMusicQueue(entries: List<QueueEntry>, startIndex: Int = 0, allowRadio: Boolean = false) {
        initFromApp()
        if (entries.isEmpty()) return
        closePreviousPip()
        val start = startIndex.coerceIn(0, entries.size - 1)
        // The player playlist is the tapped song + everything after it, so
        // player indexes and queue indexes always match.
        val playlist = if (start == 0) entries else entries.drop(start)
        stopPlayerNow()
        mode = Mode.AUDIO
        radioMode = allowRadio
        playlistMode = false
        audioOnlyMode = false
        pendingMusic.clear()
        setQueue(playlist, 0)
        resolveJob?.cancel()
        setResolving(true)
        resolveJob = scope.launch {
            try {
                val first = currentEntry ?: return@launch
                // Downloaded files play straight from disk — no resolving.
                if (first.url.startsWith("file://")) {
                    catalog = null
                    startMusicPlaylistWithRelated()
                    ensureService()
                    notify { it.onItemChanged(currentEntry) }
                    notify { it.onCatalogReady() }
                } else {
                    val info = YtRepository.streamInfo(first.url)
                    if (LiveFilter.isLive(info)) {
                        throw LiveContentException()
                    }
                    catalog = StreamCatalog(info)
                    LocalStore.addToMusicHistory(appContext, first.toVideoEntry())
                    RecommendEngine.logPlay(appContext, first.url, first.title, first.uploader, music = true)
                    // Prime the audio URL cache: the first song then starts instantly.
                    primeMusicUri(first)
                    startMusicPlaylistWithRelated()
                    ensureService()
                    notify { it.onItemChanged(currentEntry) }
                    notify { it.onCatalogReady() }
                    prefetchAhead()
                }
            } catch (e: Exception) {
                if (e is LiveContentException) {
                    notify { it.onLiveContentBlocked() }
                } else {
                    notify { it.onError(if (e.message.isNullOrBlank()) e.javaClass.simpleName else e.message!!) }
                }
            } finally {
                setResolving(false)
            }
        }
    }

    /**
     * Jumps straight to a queue position — used by the music queue / radio
     * picker so the user can choose what plays next instead of being stuck
     * with the auto-generated order.
     */
    fun playQueueIndex(index: Int) {
        if (index < 0 || index >= queue.size) return
        when (mode) {
            Mode.AUDIO -> playerRef?.let { p ->
                if (index < p.mediaItemCount) {
                    p.seekTo(index, 0L)
                    p.playWhenReady = true
                }
            }
            Mode.VIDEO -> {
                if (localVideoRecords != null) {
                    playLocalAt(index)
                } else {
                    queueIndex = index
                    resolveCurrent()
                }
            }
            Mode.NONE -> Unit
        }
    }

    fun togglePlayPause() {
        if (playerRef == null) return
        val p = sessionPlayer
        // isPlaying is false during buffering; toggle the user's intent instead.
        if (p.playWhenReady) p.pause() else p.play()
    }

    fun seekTo(positionMs: Long) {
        playerRef?.seekTo(positionMs.coerceIn(0, durationMs))
    }

    val positionMs: Long get() = playerRef?.currentPosition?.coerceAtLeast(0L) ?: 0L
    val durationMs: Long get() = playerRef?.duration?.takeIf { it > 0 } ?: 0L
    val isPlaying: Boolean get() = playerRef?.isPlaying ?: false
    val isBuffering: Boolean get() = playerRef?.playbackState == Player.STATE_BUFFERING

    /** Retry the current item without discarding the user's queue or resolving a file URL online. */
    fun retryCurrentVideo() {
        val entry = currentEntry ?: return
        if (mode != Mode.VIDEO) return
        frameRecoveryStep = 0
        if (entry.url.startsWith("file://")) {
            val record = LocalStore.downloads(appContext).firstOrNull {
                it.filePaths.firstOrNull()?.let { path -> "file://$path" == entry.url } == true
            }
            if (record == null || !startLocalFiles(record)) {
                notify { it.onError("Downloaded file is missing") }
            }
        } else {
            resolveCurrent()
        }
    }

    fun setSpeed(speed: Float) {
        playbackSpeed = speed
        playerRef?.setPlaybackSpeed(speed)
    }

    /** Music settings: pause between songs instead of auto-advancing. */
    fun applyMusicAutoplay() {
        playerRef?.setPauseAtEndOfMediaItems(sleepTimer.mode == SleepTimerState.Mode.END_OF_ITEM || !AppPrefs.musicAutoplayNext)
    }

    fun next() {
        when (mode) {
            Mode.AUDIO -> playerRef?.run {
                if (hasNextMediaItem()) seekToNextMediaItem()
            }
            Mode.VIDEO -> if (QueueNavigationPolicy.hasNext(queueIndex, queue.size)) {
                if (localVideoRecords != null) {
                    playLocalAt(queueIndex + 1)
                } else {
                    queueIndex++
                    resolveCurrent()
                }
            }
            Mode.NONE -> Unit
        }
    }

    fun previous() {
        when (mode) {
            Mode.AUDIO -> playerRef?.run {
                if (hasPreviousMediaItem()) seekToPreviousMediaItem()
                else seekTo(0)
            }
            Mode.VIDEO -> if (queueIndex > 0) {
                if (localVideoRecords != null) {
                    playLocalAt(queueIndex - 1)
                } else {
                    queueIndex--
                    resolveCurrent()
                }
            } else {
                // Already at the top of the queue: restart the video
                // (matches the behavior of the built-in previous button).
                seekTo(0)
            }
            Mode.NONE -> Unit
        }
    }

    fun stopPlayback() {
        SponsorBlock.stop()
        pendingVideo.cancel()
        retainedVideoSourceForAudio = false
        clearSleepTimer()
        watchdogJob?.cancel()
        frameWatchJob?.cancel()
        resolveJob?.cancel()
        prefetchJob?.cancel()
        pendingMusic.clear()
        playerRef?.run {
            stop()
            clearMediaItems()
        }
        mode = Mode.NONE
        playlistMode = false
        localVideoRecords = null
        queue.clear()
        queueIndex = -1
        catalog = null
        setResolving(false)
        notify { it.onQueueChanged() }
        notify { it.onItemChanged(null) }
        notify { it.onPlaybackStateChanged(false) }
    }

    // ----- Quality / track selection -----

    /**
     * @param height null = auto (best available), -1 = audio only.
     */
    fun setVideoQuality(height: Int?) {
        if (height == -1) {
            audioOnlyMode = true
            selectedHeight = -1
            autoPicked = false
        } else {
            audioOnlyMode = false
            selectedHeight = height
            // Explicit "Auto" beats the settings default for this session.
            autoPicked = height == null
        }
        frameRecoveryStep = 0
        // Explicit user action: give adaptive streams another chance even
        // if an earlier error had dropped us to a muxed fallback.
        usedFallback = false
        // The user took manual control of quality — stop auto-downshifting.
        watchdogJob?.cancel()
        downshiftHeight = null
        rebuildSource(keepPosition = true)
    }

    fun setAudioTrack(trackId: String) {
        if (catalog?.audioTracks?.none { it.id == trackId } == true) return
        selectedAudioTrackId = trackId
        // Rebuild from scratch so the selected dubbing language is actually
        // used, even if an earlier error had switched us to a muxed stream
        // (those always carry the default audio only).
        usedFallback = false
        rebuildSource(keepPosition = true)
        notify { it.onCatalogReady() }
    }

    private var retainedVideoSourceForAudio = false

    /** Instant presentation switch: retain the source, position and playback intent. */
    fun switchToAudioOnly() {
        if (mode != Mode.VIDEO || audioOnlyMode) return
        retainedVideoSourceForAudio = true
        audioOnlyMode = true
        frameWatchJob?.cancel()
        watchdogJob?.cancel()
        // Only the screen changes. Do not stop/prepare/seek or replace the source.
        notify { it.onAudioOnlyChanged(true) }
    }

    /** Reattach retained video immediately; rebuild only if an audio-only source was loaded later. */
    fun switchBackToVideo() {
        if (mode != Mode.VIDEO) return
        audioOnlyMode = false
        frameRecoveryStep = 0
        if (selectedHeight == -1) selectedHeight = null
        if (retainedVideoSourceForAudio) {
            retainedVideoSourceForAudio = false
        } else {
            rebuildSource(keepPosition = true)
        }
        notify { it.onAudioOnlyChanged(false) }
    }

    /** Convert an online music item to its video without resetting position or queue. */
    suspend fun switchMusicToVideo(): Boolean {
        val entry = currentEntry ?: return false
        if (entry.url.startsWith("file://")) return false
        val resolved = StreamCatalog(YtRepository.streamInfo(entry.url))
        if (currentEntry?.url != entry.url || (resolved.videoOnly.isEmpty() && resolved.muxed.isEmpty())) return false
        resolveJob?.cancel()
        prefetchJob?.cancel()
        mode = Mode.VIDEO
        radioMode = false
        playlistMode = true
        audioOnlyMode = false
        catalog = resolved
        selectedHeight = null
        selectedAudioTrackId = null
        usedFallback = false
        pendingMusic.clear()
        rebuildSource(keepPosition = true)
        notify { it.onAudioOnlyChanged(false) }
        notify { it.onCatalogReady() }
        return true
    }

    // ----- Favorites -----

    fun toggleFavoriteCurrent(): Boolean {
        val entry = currentEntry ?: return false
        val nowFavorite = LocalStore.toggleFavorite(appContext, entry.toVideoEntry())
        notify { it.onFavoriteChanged(entry.url, nowFavorite) }
        return nowFavorite
    }

    fun isCurrentFavorite(): Boolean {
        val entry = currentEntry ?: return false
        return LocalStore.isFavorite(appContext, entry.url)
    }

    // ----- Local downloads -----

    /** Finished video downloads being played one after another (null = not in use). */
    private var localVideoRecords: List<DownloadRecord>? = null

    /** Plays a list of finished downloads starting at [startIndex]; Next/Previous move through the list. */
    fun playDownloads(records: List<DownloadRecord>, startIndex: Int) {
        initFromApp()
        val list = records.filter { it.filePaths.isNotEmpty() }
        if (list.isEmpty()) return
        val start = startIndex.coerceIn(0, list.size - 1)
        resolveJob?.cancel()
        pendingVideo.cancel()
        setResolving(false)
        mode = Mode.VIDEO
        audioOnlyMode = false
        radioMode = false
        playlistMode = false
        pendingMusic.clear()
        queue.clear()
        list.forEach { r ->
            queue.add(
                QueueEntry(
                    url = "file://" + r.filePaths.first(), title = r.title, uploader = r.uploader,
                    thumbnailUrl = r.thumbnailUrl, durationSec = 0L, isMusic = false
                )
            )
        }
        localVideoRecords = list
        playLocalAt(start)
    }

    private fun playLocalAt(index: Int) {
        val list = localVideoRecords ?: return
        val record = list.getOrNull(index) ?: return
        frameWatchJob?.cancel()
        frameRecoveryStep = 0
        queueIndex = index
        notify { it.onQueueChanged() }
        notify { it.onItemChanged(currentEntry) }
        if (!startLocalFiles(record)) {
            notify { it.onError("Downloaded file is missing") }
            return
        }
        catalog = null
        notify { it.onCatalogReady() }
        ensureService()
    }

    fun playDownload(record: DownloadRecord) {
        initFromApp()
        localVideoRecords = null
        if (record.filePaths.isEmpty()) return
        resolveJob?.cancel()
        pendingVideo.cancel()
        setResolving(false)
        frameWatchJob?.cancel()
        frameRecoveryStep = 0
        mode = if (record.type == DownloadCenter.TYPE_AUDIO) Mode.AUDIO else Mode.VIDEO
        audioOnlyMode = record.type == DownloadCenter.TYPE_AUDIO
        radioMode = false
        playlistMode = false
        pendingMusic.clear()
        queue.clear()
        queue.add(
            QueueEntry(
                url = "file://" + record.filePaths.first(),
                title = record.title,
                uploader = record.uploader,
                thumbnailUrl = record.thumbnailUrl,
                durationSec = 0L,
                isMusic = record.type == DownloadCenter.TYPE_AUDIO
            )
        )
        queueIndex = 0
        notify { it.onQueueChanged() }
        notify { it.onItemChanged(currentEntry) }

        if (!startLocalFiles(record)) {
            notify { it.onError("Downloaded file is missing") }
            return
        }
        catalog = null
        notify { it.onCatalogReady() }
        ensureService()
    }

    /** Prepares and starts the finished download's files on the player. False when none exist. */
    private fun startLocalFiles(record: DownloadRecord): Boolean {
        retainedVideoSourceForAudio = false
        val sources = record.filePaths
            .filter { File(it).exists() }
            .map { path ->
                progressiveSource(
                    MediaItem.Builder().setUri(Uri.fromFile(File(path))).build()
                )
            }
        if (sources.isEmpty()) return false
        val source = if (sources.size == 1) sources[0] else MergingMediaSource(*sources.toTypedArray())
        videoFrameSeen = false
        player.run {
            setMediaSource(source, 0L)
            prepare()
            playWhenReady = if (videoRequestPending) pendingVideo.playWhenReady else true
            setPlaybackSpeed(playbackSpeed)
        }
        startFrameWatch()
        return true
    }

    /** A finished on-device video download of [url] whose files are all still there, if any. */
    private fun localVideoRecord(url: String): DownloadRecord? =
        DownloadCenter.recordsFor(appContext, url).firstOrNull { record ->
            record.status == DownloadCenter.STATUS_DONE &&
                record.type != DownloadCenter.TYPE_AUDIO &&
                record.filePaths.isNotEmpty() &&
                record.filePaths.all { File(it).exists() }
        }

    // ----- Resolution -----

    private fun setQueue(newQueue: List<QueueEntry>, startIndex: Int) {
        localVideoRecords = null
        queue.clear()
        queue.addAll(newQueue)
        queueIndex = startIndex
        notify { it.onQueueChanged() }
        notify { it.onItemChanged(currentEntry) }
    }

    private fun initFromApp() {
        if (this::appContext.isInitialized) return
        throw IllegalStateException("PlaybackCenter.init(context) must be called in Application.onCreate()")
    }

    /** Video mode: resolve the current item and play it. */
    private fun resolveCurrent() {
        val entry = currentEntry ?: return
        resolveJob?.cancel()
        val requestToken = pendingVideo.begin()
        // Acknowledge queue selection now, not after online stream extraction.
        // The previous stream must not keep sounding like the newly selected item.
        playerRef?.pause()
        frameWatchJob?.cancel()
        frameRecoveryStep = 0
        // A previous video's startup watchdog must not act on this one, and
        // its quality drop applies to that video only.
        watchdogJob?.cancel()
        downshiftHeight = null
        dashBlocked = false
        dashActive = false
        // Drop the PREVIOUS video's catalog immediately: the watch page
        // listens to onItemChanged and re-binds from the entry alone, so the
        // action pills / subscribe / views of the old video must not linger
        // (and must stay hidden) until the new catalog arrives.
        catalog = null
        notify { it.onItemChanged(currentEntry) }
        setResolving(true)
        resolveJob = scope.launch {
            try {
                // Playlist videos with a finished download play from disk:
                // no network needed, so an offline playlist keeps working.
                val local = if (playlistMode) localVideoRecord(entry.url) else null
                if (local != null && startLocalFiles(local)) {
                    notify { it.onItemChanged(currentEntry) }
                    notify { it.onCatalogReady() }
                    ensureService()
                    return@launch
                }
                val info = YtRepository.streamInfo(entry.url)
                if (LiveFilter.isLive(info)) {
                    throw LiveContentException()
                }
                catalog = StreamCatalog(info)
                usedFallback = false
                SponsorBlock.start(appContext, entry.url)
                LocalStore.addToHistory(appContext, entry.toVideoEntry())
                RecommendEngine.logPlay(appContext, entry.url, entry.title, entry.uploader)
                applySources(playbackSpeed)
                notify { it.onItemChanged(currentEntry) }
                notify { it.onCatalogReady() }
                extendQueueFromRelated()
                ensureService()
            } catch (e: CancellationException) {
                // Superseded by a newer resolve: not an error for the user.
                throw e
            } catch (e: Exception) {
                // In a playlist an unavailable / live item is skipped so the
                // rest of the list still plays.
                if (!skipBrokenPlaylistItem()) {
                    if (e is LiveContentException) {
                        notify { it.onLiveContentBlocked() }
                    } else {
                        notify { it.onError(if (e.message.isNullOrBlank()) e.javaClass.simpleName else e.message!!) }
                    }
                }
            } finally {
                // A cancelled older resolve must not clear a newer selection.
                if (pendingVideo.complete(requestToken)) setResolving(false)
            }
        }
    }

    /** Tracks + broadcasts "resolving" so a screen that attaches late can still show the spinner. */
    private fun setResolving(resolving: Boolean) {
        isResolving = resolving
        notify { it.onResolvingChanged(resolving) }
    }

    /**
     * Playlist playback: hops over an item that cannot play (removed video,
     * live stream, hard playback error) so the list keeps going. Returns
     * false when this is not a playlist or it was the last item — the caller
     * then reports the error as usual.
     */
    private fun skipBrokenPlaylistItem(): Boolean {
        if (!playlistMode || mode != Mode.VIDEO || queueIndex >= queue.size - 1) return false
        val failedIndex = queueIndex
        notify { it.onNotice("This video can't be played — skipping to the next one") }
        // Posted rather than called inline: this can run inside the resolve
        // coroutine that next() is about to cancel and replace. The index
        // check drops the hop if the user already moved on by themselves.
        scope.launch(Dispatchers.Main) {
            if (mode == Mode.VIDEO && playlistMode && queueIndex == failedIndex) next()
        }
        return true
    }

    /** Music mode: resolve metadata for the current song (downloads, radio). */
    private fun resolveCatalog(entry: QueueEntry) {
        resolveJob?.cancel()
        setResolving(true)
        resolveJob = scope.launch {
            try {
                val info = YtRepository.streamInfo(entry.url)
                if (LiveFilter.isLive(info)) {
                    throw LiveContentException()
                }
                catalog = StreamCatalog(info)
                LocalStore.addToMusicHistory(appContext, entry.toVideoEntry())
                RecommendEngine.logPlay(appContext, entry.url, entry.title, entry.uploader, music = true)
                // Share the resolved URL with the loading thread (if it has
                // not found it already) so a re-visit starts instantly.
                primeMusicUri(entry)
                notify { it.onItemChanged(currentEntry) }
                notify { it.onCatalogReady() }
                if (radioMode) {
                    extendRadioFromRelated()
                }
            } catch (e: Exception) {
                if (e is LiveContentException) {
                    notify { it.onLiveContentBlocked() }
                } else {
                    notify { it.onError(if (e.message.isNullOrBlank()) e.javaClass.simpleName else e.message!!) }
                }
            } finally {
                setResolving(false)
            }
        }
    }

    /** Appends related items so next/previous + autoplay keep working (video mode). */
    private fun extendQueueFromRelated() {
        if (playlistMode) return
        val rel = catalog?.related ?: return
        val known = queue.map { it.url }.toSet()
        val additions = rel.filter { it.url !in known }.take(20)
            .map { it.toQueueEntry(isMusic = mode == Mode.AUDIO) }
        if (additions.isEmpty()) return
        queue.addAll(additions)
        notify { it.onQueueChanged() }
    }

    /**
     * Grows the music playlist with related songs before it runs dry, so a
     * radio is effectively endless. YouTube's "related" list alone only holds
     * a couple of dozen items (and shrinks after de-duplication), so when it
     * cannot fill the queue a song search for the same artist tops it up.
     */
    private fun extendRadioFromRelated() {
        val rel = catalog?.related ?: return
        val idx = playerRef?.currentMediaItemIndex ?: queueIndex
        val remaining = (queue.size - idx - 1).coerceAtLeast(0)
        // Only extend when the upcoming part of the queue is running low,
        // otherwise the playlist would grow without bound.
        if (remaining >= RADIO_REFILL_BELOW) return
        val known = queue.map { it.url }.toSet()
        val additions = rel.filter { it.url.isNotBlank() && it.url !in known && !LiveFilter.isLive(it) }
            .take(RADIO_BATCH)
            .map { it.toQueueEntry(isMusic = true) }
        appendRadioEntries(additions)
        if (additions.size + remaining < RADIO_MIN_UPCOMING) {
            topUpRadioFromSearch(currentEntry)
        }
    }

    private fun appendRadioEntries(additions: List<QueueEntry>) {
        if (additions.isEmpty()) return
        val known = queue.map { it.url }.toHashSet()
        val fresh = additions.filter { known.add(it.url) }
        if (fresh.isEmpty()) return
        queue.addAll(fresh)
        playerRef?.addMediaItems(fresh.map { musicMediaItem(it) })
        notify { it.onQueueChanged() }
    }

    /** Fallback source for the radio: more songs by the same artist. */
    private fun topUpRadioFromSearch(seed: QueueEntry?) {
        seed ?: return
        val query = seed.uploader.removeSuffix(" - Topic").ifBlank { seed.title }
        if (query.isBlank()) return
        scope.launch {
            try {
                val result = YtRepository.searchMusic(query, null)
                // The radio may have been restarted / stopped meanwhile.
                if (!radioMode || currentEntry?.url != seed.url) return@launch
                val known = queue.map { it.url }.toSet()
                val more = result.items
                    .filter { it.url.isNotBlank() && it.url !in known && !LiveFilter.isLive(it) }
                    .take(RADIO_BATCH)
                    .map { it.toQueueEntry(isMusic = true) }
                appendRadioEntries(more)
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                // Best-effort only: the related list keeps the radio going.
            }
        }
    }

    /** Set by the visible watch page; return true to take over the hand-over to the next video. */
    @Volatile var autoplayInterceptor: (() -> Boolean)? = null

    fun nextQueueEntry(): QueueEntry? = queue.getOrNull(queueIndex + 1)

    /** Continues to the next video after a countdown (no-op if playback moved on meanwhile). */
    fun proceedAutoplay() {
        if (mode == Mode.VIDEO && playerRef?.playbackState == Player.STATE_ENDED) advance()
    }

    private fun advance() {
        if (queueIndex < queue.size - 1) {
            next()
        }
        // Queue exhausted: radio already keeps extending while playing.
    }

    private fun onPlayerFailed(error: PlaybackException) {
        // A live URL slipping through data-source resolution (playtube://
        // queue lookups run on the loader thread, not through the
        // resolveCatalog()/playMusicQueue() try/catch above) surfaces here
        // instead, wrapped as the PlaybackException's cause. Checked lazily
        // (not returned early) so the existing skip-to-next-song / skip-
        // broken-playlist-item behavior below still runs first, exactly as
        // it did before live content had its own exception type.
        val isLive = generateSequence(error as Throwable) { it.cause }
            .any { it is LiveContentException }
        fun notifyFailure() {
            if (isLive) notify { it.onLiveContentBlocked() }
            else notify { it.onError("Playback error: ${error.errorCodeName}") }
        }
        // Music mode: skip a broken song so the radio keeps going.
        if (mode == Mode.AUDIO) {
            playerRef?.run {
                if (hasNextMediaItem()) {
                    seekToNextMediaItem()
                    return
                }
            }
            notifyFailure()
            return
        }
        val c = catalog ?: run {
            if (!skipBrokenPlaylistItem()) {
                notifyFailure()
            }
            return
        }
        // The adaptive (DASH) session failed: retry the same video on the plain
        // progressive path before any other fallback.
        if (dashActive) {
            dashBlocked = true
            android.util.Log.w("PlayTubeStartup", "adaptive source failed: ${error.errorCodeName}")
            rebuildSource(keepPosition = true)
            return
        }
        // The selected dubbing track failed to load: retry once with the
        // default audio before giving up on adaptive streams.
        if (selectedAudioTrackId != null && !usedFallback) {
            selectedAudioTrackId = null
            notify { it.onNotice("Selected audio track unavailable - using the default track") }
            rebuildSource(keepPosition = true)
            notify { it.onCatalogReady() }
            return
        }
        // If a high-quality merged source failed, fall back to the best muxed stream.
        if (!usedFallback && c.muxed.isNotEmpty()) {
            usedFallback = true
            // A muxed stream always carries the default audio only.
            val hadTrackChoice = selectedAudioTrackId != null
            selectedAudioTrackId = null
            if (hadTrackChoice) {
                notify { it.onNotice("Playing a lower-quality stream with the default audio track") }
            }
            rebuildSource(keepPosition = true)
            notify { it.onCatalogReady() }
            return
        }
        if (skipBrokenPlaylistItem()) return
        notifyFailure()
    }

    /** Builds and applies the media source for the current entry + selections (video mode). */
    private fun applySources(speed: Float) {
        val entry = currentEntry ?: return
        val c = catalog ?: return
        val source = buildSource(entry, c) ?: run {
            notify { it.onError("No playable streams found") }
            return
        }
        sourceAppliedAt = SystemClock.elapsedRealtime()
        videoFrameSeen = false
        player.run {
            setMediaSource(source, 0L)
            prepare()
            playWhenReady = if (videoRequestPending) pendingVideo.playWhenReady else true
            setPlaybackSpeed(speed)
        }
        startStartupWatchdog()
        startFrameWatch()
    }

    /**
     * Watches the freshly prepared video: [STARTUP_LIMIT_MS] without a first
     * frame, or a [STALL_LIMIT_MS] stall during the first healthy stretch,
     * drops one quality tier via [downshiftOneTier]. Retires itself once the
     * connection has proven it can sustain the current quality.
     */
    private fun startStartupWatchdog() {
        // Local files and background audio have no video bitrate to manage.
        if (mode != Mode.VIDEO || audioOnlyMode) return
        watchdogJob?.cancel()
        watchdogDownshifts = 0
        watchdogJob = scope.launch {
            var preparedAt = SystemClock.elapsedRealtime()
            var lastPollAt = preparedAt
            var readyAt = 0L
            var healthyMs = 0L
            var stallSince = 0L
            while (isActive) {
                delay(400)
                val now = SystemClock.elapsedRealtime()
                val dt = (now - lastPollAt).coerceAtMost(1_000)
                lastPollAt = now
                val p = playerRef ?: break
                if (!p.playWhenReady) {
                    preparedAt = now
                    stallSince = 0L
                    continue
                }
                when (p.playbackState) {
                    Player.STATE_IDLE, Player.STATE_ENDED -> return@launch
                    Player.STATE_READY -> {
                        if (readyAt == 0L) readyAt = now
                        if (p.isPlaying && videoFrameSeen) {
                            stallSince = 0L
                            healthyMs += dt
                            // Connection proven: 15s of uninterrupted playback.
                            if (healthyMs >= 15_000) return@launch
                        }
                    }
                    Player.STATE_BUFFERING -> {
                        if (stallSince == 0L) stallSince = now
                        val startup = readyAt == 0L
                        val waited = now - if (startup) preparedAt else stallSince
                        val limit = if (startup) STARTUP_LIMIT_MS
                        else if (dashActive) STALL_LIMIT_MS * 3 else STALL_LIMIT_MS
                        if (waited >= limit) {
                            if (dashActive) {
                                // The adaptive start did not deliver either: fall
                                // back to the plain stream (which the tier
                                // downshifts below can then still tune).
                                dashBlocked = true
                                rebuildSource(keepPosition = !startup)
                                preparedAt = SystemClock.elapsedRealtime()
                                readyAt = 0L
                                healthyMs = 0L
                                stallSince = 0L
                                continue
                            }
                            // Floor reached / out of shifts: stop watching.
                            if (!downshiftOneTier(keepPosition = !startup)) return@launch
                            preparedAt = SystemClock.elapsedRealtime()
                            readyAt = 0L
                            healthyMs = 0L
                            stallSince = 0L
                        }
                    }
                }
            }
        }
    }

    /**
     * Drops the video to the next lower available height (video-only or
     * muxed). Returns false when already at the floor / out of shifts, which
     * retires the watchdog — there is nothing left to try.
     */
    private fun downshiftOneTier(keepPosition: Boolean): Boolean {
        if (watchdogDownshifts >= 2) return false
        val c = catalog ?: return false
        val current = effectiveSelectedHeight(c) ?: run {
            // "Auto": the top video-only stream is what is playing.
            c.videoOnly.firstOrNull()?.effectiveHeight() ?: c.muxed.firstOrNull()?.effectiveHeight()
        } ?: return false
        val lower = (c.videoOnly.map { it.effectiveHeight() } +
            c.muxed.map { it.effectiveHeight() })
            .distinct()
            .filter { it < current }
            .sortedDescending()
        if (lower.isEmpty()) return false
        val target = lower.first()
        // Only THIS video is dropped; the user's own pick / settings default
        // stay untouched for the next video.
        downshiftHeight = target
        // Honor the explicit height even if an earlier error had forced the
        // muxed fallback (a failure here just re-triggers that fallback).
        usedFallback = false
        watchdogDownshifts++
        rebuildSource(keepPosition = keepPosition)
        notify { it.onNotice("Slow connection — switching to ${target}p") }
        return true
    }

    private fun rebuildSource(keepPosition: Boolean) {
        val entry = currentEntry ?: return
        val c = catalog ?: return
        val position = if (keepPosition) positionMs else 0L
        val wasPlaying = playerRef?.playWhenReady ?: true
        val source = buildSource(entry, c) ?: return
        sourceAppliedAt = SystemClock.elapsedRealtime()
        videoFrameSeen = false
        player.run {
            setMediaSource(source, position)
            prepare()
            playWhenReady = wasPlaying || !keepPosition
            setPlaybackSpeed(playbackSpeed)
        }
        startFrameWatch()
    }

    /** Selected caption language tag, or null = captions off (reset per video). */
    @Volatile var subtitleLang: String? = null
        private set

    fun setSubtitleLanguage(tag: String?) {
        subtitleLang = tag
        applySubtitlePrefs()
    }

    private fun applySubtitlePrefs() {
        val p = playerRef ?: player
        val b = p.trackSelectionParameters.buildUpon()
        val lang = subtitleLang
        if (lang == null) {
            b.setTrackTypeDisabled(C.TRACK_TYPE_TEXT, true)
        } else {
            b.setTrackTypeDisabled(C.TRACK_TYPE_TEXT, false).setPreferredTextLanguage(lang)
        }
        p.trackSelectionParameters = b.build()
    }

    private fun buildSource(entry: QueueEntry, c: StreamCatalog): MediaSource? {
        val base = buildBaseSource(entry, c) ?: return null
        if (mode != Mode.VIDEO || audioOnlyMode || c.subtitles.isEmpty()) return base
        val extras = c.subtitles.map { sub ->
            val cfg = MediaItem.SubtitleConfiguration.Builder(Uri.parse(sub.url))
                .setMimeType(sub.mime)
                .setLanguage(sub.lang)
                .setLabel(sub.label)
                .setSelectionFlags(0)
                .build()
            androidx.media3.exoplayer.source.SingleSampleMediaSource.Factory(dataSourceFactory)
                .createMediaSource(cfg, C.TIME_UNSET)
        }
        applySubtitlePrefs()
        return MergingMediaSource(base, *extras.toTypedArray())
    }

    private fun buildBaseSource(entry: QueueEntry, c: StreamCatalog): MediaSource? {
        retainedVideoSourceForAudio = false
        val metadata = MediaMetadata.Builder()
            .setTitle(entry.title)
            .setArtist(entry.uploader)
            .setArtworkUri(entry.thumbnailUrl.takeIf { it.isNotBlank() }?.let(Uri::parse))
            .build()

        // Music / audio-only background mode: pick the best audio stream.
        if (mode == Mode.AUDIO || audioOnlyMode) {
            val audio = if (mode == Mode.AUDIO) {
                pickMusicAudio(c)
            } else {
                audioForSelection(c) ?: c.audioTracks.firstOrNull()?.best
            }
            if (audio == null && c.muxed.isNotEmpty()) {
                return progressiveSource(MediaItem.Builder().setUri(audioUri(c.muxed.first())).setMediaMetadata(metadata).build())
            }
            if (audio != null) {
                return progressiveSource(MediaItem.Builder().setUri(audioUri(audio)).setMediaMetadata(metadata).build())
            }
            return null
        }

        // Video mode: prefer an adaptive video-only stream merged with audio
        // (that's how qualities above 360p are supported).
        val audio = audioForSelection(c)

        // "Auto" / the settings default: start like the official player — an
        // adaptive DASH session that begins with small segments at a quality the
        // line can carry and adapts per segment. An explicit quality pick, a
        // failed / slow adaptive start, or a manifest we cannot build all use the
        // plain progressive path below, exactly as before.
        if (adaptiveEligible()) {
            val capHeight = if (autoPicked) 0 else AppPrefs.defaultVideoHeightNow(appContext)
            val mediaItem = MediaItem.Builder()
                .setUri(Uri.parse("https://playtube.invalid/manifest.mpd"))
                .setMediaMetadata(metadata)
                .build()
            val dash = DashSources.create(dataSourceFactory, mediaItem, c.allVideoOnly, audio, c.durationSec)
            if (dash != null) {
                applyVideoCap(capHeight)
                dashActive = true
                return dash
            }
        }
        dashActive = false
        applyVideoCap(0)
        val video = videoForSelection(c)

        if (video != null && video.isVideoOnly && audio != null) {
            val videoItem = MediaItem.Builder().setUri(audioUri(video)).setMediaMetadata(metadata).build()
            val audioItem = MediaItem.Builder().setUri(audioUri(audio)).build()
            return MergingMediaSource(
                progressiveSource(videoItem),
                progressiveSource(audioItem)
            )
        }
        if (video != null) {
            return progressiveSource(MediaItem.Builder().setUri(audioUri(video)).setMediaMetadata(metadata).build())
        }
        // Never silently play audio-only while the UI says Video.
        return null
    }

    private fun adaptiveEligible(): Boolean =
        AppPrefs.smartStreaming && !dashBlocked && !usedFallback &&
            selectedHeight == null && downshiftHeight == null

    /** Adaptive quality ceiling (0 = none). Cleared for fixed-quality progressive playback. */
    private fun applyVideoCap(capHeight: Int) {
        val p = playerRef ?: player
        val builder = p.trackSelectionParameters.buildUpon()
            .setTrackTypeDisabled(C.TRACK_TYPE_VIDEO, !appVisible)
            .setPreferredVideoMimeTypes("video/avc", "video/x-vnd.on2.vp9", "video/av01")
        if (capHeight > 0) builder.setMaxVideoSize(Int.MAX_VALUE, capHeight)
        else builder.clearVideoSizeConstraints()
        p.trackSelectionParameters = builder.build()
    }

    private fun videoForSelection(c: StreamCatalog): VideoStream? {
        if (usedFallback && c.muxed.isNotEmpty()) return c.muxed.first()
        val height = downshiftHeight ?: selectedHeight
        return when {
            height == null -> {
                val default = AppPrefs.defaultVideoHeightNow(appContext)
                if (default > 0 && !autoPicked) {
                    // User default: the chosen quality, or the best one below
                    // it when the exact height is not available.
                    val candidates = c.videoOnly.ifEmpty { c.muxed }
                    candidates.filter { it.effectiveHeight() <= default }
                        .maxByOrNull { it.effectiveHeight() }
                        ?: candidates.minByOrNull { it.effectiveHeight() }
                } else {
                    c.videoOnly.firstOrNull() ?: c.muxed.firstOrNull()
                }
            }
            c.videoOnly.any { it.effectiveHeight() == height } ->
                c.videoOnly.first { it.effectiveHeight() == height }
            c.muxed.any { it.effectiveHeight() == height } ->
                c.muxed.first { it.effectiveHeight() == height }
            else -> c.videoOnly.firstOrNull() ?: c.muxed.firstOrNull()
        }
    }

    private fun audioForSelection(c: StreamCatalog): AudioStream? {
        val selected = selectedAudioTrackId
        return when {
            selected != null -> c.audioTracks.firstOrNull { it.id == selected }?.best
                ?: c.audioTracks.firstOrNull()?.best
            else -> c.audioTracks.firstOrNull()?.best
        }
    }

    /** Picks the default audio track's stream at the user's music quality tier. */
    private fun pickMusicAudio(c: StreamCatalog): AudioStream? {
        val group = c.audioTracks.firstOrNull() ?: return null
        val streams = group.streams.filter { it.isUrl && it.averageBitrate > 0 }
        if (streams.isEmpty()) return group.best
        return when (AppPrefs.musicAudioQuality) {
            AppPrefs.AUDIO_QUALITY_LOW -> streams.last()
            AppPrefs.AUDIO_QUALITY_MEDIUM -> streams[streams.size / 2]
            else -> streams.first()
        }
    }

    private fun audioUri(stream: AudioStream): Uri = Uri.parse(stream.content)
    private fun audioUri(stream: VideoStream): Uri = Uri.parse(stream.content)

    private fun progressiveSource(item: MediaItem): MediaSource =
        ProgressiveMediaSource.Factory(dataSourceFactory).createMediaSource(item)

    // ----- Music playlist -----

    /**
     * Builds the lazy-resolving playlist on the player: the current song
     * plus (in radio mode) a first batch of related songs so next / previous
     * and the notification controls exist from the very first moment. Each
     * item uses a virtual playtube:// URI that the resolving data source
     * swaps for the real audio stream URL right before it is opened.
     */
    private fun startMusicPlaylistWithRelated() {
        val first = currentEntry ?: return
        val items = mutableListOf(musicMediaItem(first))
        if (radioMode) {
            catalog?.related
                ?.filter { it.url.isNotBlank() && it.url != first.url && !LiveFilter.isLive(it) }
                ?.take(RADIO_FIRST_BATCH)
                ?.forEach { rel ->
                    val qe = rel.toQueueEntry(isMusic = true)
                    if (queue.none { it.url == qe.url }) {
                        queue.add(qe)
                        items.add(musicMediaItem(qe))
                    }
                }
            notify { it.onQueueChanged() }
        } else {
            // Fixed playlist (favorites / downloads): queue the whole list.
            queue.drop(1).forEach { items.add(musicMediaItem(it)) }
        }
        player.run {
            setMediaItems(items, 0, 0L)
            prepare()
            playWhenReady = true
            setPlaybackSpeed(playbackSpeed)
            applyMusicAutoplay()
        }
        // "Related" alone rarely fills a radio: top it up with the artist's songs.
        if (radioMode && items.size < RADIO_MIN_UPCOMING) {
            topUpRadioFromSearch(first)
        }
    }

    private fun musicMediaItem(entry: QueueEntry): MediaItem {
        val metadata = MediaMetadata.Builder()
            .setTitle(entry.title)
            .setArtist(entry.uploader)
            .setArtworkUri(entry.thumbnailUrl.takeIf { it.isNotBlank() }?.let(Uri::parse))
            .build()
        // Downloaded songs play straight from disk.
        if (entry.url.startsWith("file://")) {
            return MediaItem.Builder()
                .setUri(Uri.parse(entry.url))
                .setMediaMetadata(metadata)
                .build()
        }
        val key = "music-${musicItemId.incrementAndGet()}"
        // Bounded like musicUriCache: entries now live for the whole session
        // (see resolveMusicUri) instead of being removed after first use, so
        // a very long continuous radio session must not leak indefinitely.
        if (pendingMusic.size > 128) pendingMusic.clear()
        pendingMusic[key] = entry
        return MediaItem.Builder()
            .setUri("playtube://queue/$key")
            .setMediaMetadata(metadata)
            .build()
    }

    /**
     * Blocking stream resolution for the playlist (runs on the loading thread).
     * ExoPlayer's ResolvingDataSource can call this more than once for the
     * same media item — a mid-buffer retry, a re-open after a seek, etc. —
     * so the pendingMusic entry must stay around for the life of the
     * playlist item, not just the first successful resolution. Removing it
     * eagerly made every repeat call throw "vanished", which the player
     * treated as a hard playback error and skipped to the next track (which
     * then hit the same problem a few seconds later).
     */
    private fun resolveMusicUri(key: String): Uri {
        val entry = pendingMusic[key]
            ?: throw IOException("Playlist item vanished: $key")
        // Fast path: already resolved (also covers repeat calls for the
        // same item — retries, buffering re-opens, etc).
        musicUriCache[entry.url]?.let { return it }
        val info = runBlocking { YtRepository.streamInfo(entry.url) }
        if (LiveFilter.isLive(info)) {
            throw LiveContentException()
        }
        val audio = pickMusicAudio(StreamCatalog(info))
            ?: throw IOException("No audio stream found")
        return cacheMusicUri(entry.url, audio.content)
    }

    /** Caches the resolved audio URL (bounded: a long session must not leak entries). */
    private fun cacheMusicUri(url: String, content: String): Uri {
        if (musicUriCache.size > 64) musicUriCache.clear()
        val uri = Uri.parse(content)
        musicUriCache[url] = uri
        return uri
    }

    /** Stores the selected-quality audio URL of the current catalog for [entry]. */
    private fun primeMusicUri(entry: QueueEntry) {
        val best = catalog?.let { pickMusicAudio(it) } ?: return
        cacheMusicUri(entry.url, best.content)
    }

    /** Resolves the next couple of songs in the background so transitions are instant. */
    private fun prefetchAhead() {
        if (mode != Mode.AUDIO) return
        val idx = playerRef?.currentMediaItemIndex ?: queueIndex
        val targets = ((idx + 1) until minOf(idx + if (Net.isOnWifi(appContext)) 3 else 2, queue.size))
            .mapNotNull { queue.getOrNull(it) }
            .filter { !it.url.startsWith("file://") && !musicUriCache.containsKey(it.url) }
        if (targets.isEmpty()) return
        prefetchJob?.cancel()
        prefetchJob = scope.launch(Dispatchers.IO) {
            targets.forEach { entry ->
                runCatching {
                    val info = YtRepository.streamInfo(entry.url)
                    pickMusicAudio(StreamCatalog(info))?.let { audio ->
                        cacheMusicUri(entry.url, audio.content)
                    }
                }
            }
        }
    }

    val dataSourceFactory: DefaultDataSource.Factory by lazy {
        val http = DefaultHttpDataSource.Factory()
            .setUserAgent(OkHttpDownloader.USER_AGENT)
            .setConnectTimeoutMs(15_000)
            .setReadTimeoutMs(20_000)
            .setAllowCrossProtocolRedirects(true)
        val resolving = ResolvingDataSource.Factory(http) { dataSpec ->
            val uri = dataSpec.uri
            if (uri.scheme == "playtube") {
                val key = "${uri.host ?: ""}${uri.path.orEmpty()}".removePrefix("//")
                    .removePrefix("queue/")
                forceInitialRangeHeader(dataSpec.buildUpon().setUri(resolveMusicUri(key)).build())
            } else {
                forceInitialRangeHeader(dataSpec)
            }
        }
        // MULTI-THREADED PLAYBACK: a single connection ramps too slowly for
        // 720p/1080p videos — the startup buffer could not fill in time, so
        // big videos sat on the spinner and tripped the "Slow connection"
        // watchdog while small videos started instantly. ParallelRangeDataSource
        // splits every stream into ~1 MiB chunks and pulls 4 of them over
        // parallel HTTP Range connections (the exact trick DownloadCenter
        // uses, which googlevideo demonstrably supports), serving bytes to
        // the player the moment they land. Any server/transfer hiccup degrades
        // to one plain connection at the player's current byte — never any
        // skipped or duplicated data.
        val parallel = ParallelRangeDataSource.Factory(resolving)
        DefaultDataSource.Factory(appContext, parallel)
    }

    /**
     * YouTube (googlevideo) serves the *first* open of a progressive stream
     * (no Range header: position 0 + unknown length) from a throttled path,
     * which is why videos took ages to start while a seek (which always sends
     * a Range header) started instantly. Forcing `Range: bytes=0-` on that
     * initial open puts it on the same fast path a seek uses. Seeks and
     * re-opens (position != 0) are untouched: DefaultHttpDataSource computes
     * and overrides its own Range header for them after applying our
     * httpRequestHeaders, so this can never corrupt a real range request.
     */
    private fun forceInitialRangeHeader(spec: DataSpec): DataSpec {
        val scheme = spec.uri.scheme
        if (scheme != "http" && scheme != "https") return spec
        // C.LENGTH_UNSET is an int constant (media3) while DataSpec.length is
        // a long - Kotlin needs the explicit widening conversion.
        if (spec.position != 0L || spec.length != C.LENGTH_UNSET.toLong()) return spec
        if (spec.httpRequestHeaders.containsKey("Range")) return spec
        val headers = HashMap(spec.httpRequestHeaders)
        headers["Range"] = "bytes=0-"
        return spec.buildUpon().setHttpRequestHeaders(headers).build()
    }

    // ----- View attach helpers -----

    /**
     * Player-side wrapper handed to [PlayerView] so the controller's next /
     * previous buttons reflect the APP queue (related videos, radio playlist)
     * instead of the ExoPlayer playlist — video mode plays one MediaSource at
     * a time, so without this the next button was permanently grayed out.
     *
     * NOTE: nested classes inside an `object` cannot use the `inner` modifier
     * (Kotlin rejects it), so they reach the singleton's state through
     * qualified access — same pattern as DownloadCenter.DownloadJob.
     */
    @OptIn(UnstableApi::class)
    private class QueueForwardingPlayer(player: ExoPlayer) :
        ForwardingPlayer(player) {

        private val listenerBridges = mutableMapOf<Player.Listener, Player.Listener>()
        private var lastCommands: Player.Commands? = null
        private var reportedPlayWhenReady = super.getPlayWhenReady()
        private var reportedPlaybackState = super.getPlaybackState()
        private var reportedIsPlaying = super.isPlaying()
        private var reportedMetadata = super.getMediaMetadata()

        // This is the logical queue player seen by the session. While extracting
        // a new video's URL it is buffering, not still playing the old video.
        override fun getPlayWhenReady(): Boolean =
            if (videoRequestPending) pendingVideo.playWhenReady else super.getPlayWhenReady()

        override fun getPlaybackState(): Int =
            if (videoRequestPending) Player.STATE_BUFFERING else super.getPlaybackState()

        override fun isPlaying(): Boolean = !videoRequestPending && super.isPlaying()

        override fun getMediaMetadata(): MediaMetadata {
            if (!videoRequestPending) return super.getMediaMetadata()
            val entry = PlaybackCenter.currentEntry ?: return super.getMediaMetadata()
            return MediaMetadata.Builder()
                .setTitle(entry.title)
                .setArtist(entry.uploader)
                .setArtworkUri(entry.thumbnailUrl.takeIf { it.isNotBlank() }?.let(Uri::parse))
                .build()
        }

        override fun setPlayWhenReady(playWhenReady: Boolean) {
            if (videoRequestPending) {
                pendingVideo.setPlayWhenReady(playWhenReady)
                refreshSessionState()
                PlaybackCenter.notify { it.onPlaybackStateChanged(false) }
            } else {
                super.setPlayWhenReady(playWhenReady)
            }
        }

        override fun play() = setPlayWhenReady(true)
        override fun pause() = setPlayWhenReady(false)

        /** Emit actual logical-state changes synchronously; never poll or fake READY. */
        fun refreshSessionState() {
            refreshAvailableCommands()
            val ready = playWhenReady
            val state = playbackState
            val playing = isPlaying
            val metadata = mediaMetadata
            val readyChanged = ready != reportedPlayWhenReady
            val stateChanged = state != reportedPlaybackState
            val playingChanged = playing != reportedIsPlaying
            val metadataChanged = metadata != reportedMetadata
            if (!readyChanged && !stateChanged && !playingChanged && !metadataChanged) return
            reportedPlayWhenReady = ready
            reportedPlaybackState = state
            reportedIsPlaying = playing
            reportedMetadata = metadata
            val flags = androidx.media3.common.FlagSet.Builder()
            if (readyChanged) flags.add(Player.EVENT_PLAY_WHEN_READY_CHANGED)
            if (stateChanged) flags.add(Player.EVENT_PLAYBACK_STATE_CHANGED)
            if (playingChanged) flags.add(Player.EVENT_IS_PLAYING_CHANGED)
            if (metadataChanged) flags.add(Player.EVENT_MEDIA_METADATA_CHANGED)
            val events = Player.Events(flags.build())
            val snapshot = listenerBridges.keys.toList()
            snapshot.forEach { listener ->
                if (readyChanged) listener.onPlayWhenReadyChanged(ready, Player.PLAY_WHEN_READY_CHANGE_REASON_USER_REQUEST)
                if (stateChanged) listener.onPlaybackStateChanged(state)
                if (playingChanged) listener.onIsPlayingChanged(playing)
                if (metadataChanged) listener.onMediaMetadataChanged(metadata)
            }
            snapshot.forEach { it.onEvents(this, events) }
        }

        override fun addListener(listener: Player.Listener) {
            if (listenerBridges.containsKey(listener)) return
            // Java-default callbacks require explicit forwarding, not Kotlin `by` delegation.
            val bridge = object : PlayerListenerBridge(listener) {
                override fun onPlayWhenReadyChanged(playWhenReady: Boolean, reason: Int) {
                    listener.onPlayWhenReadyChanged(this@QueueForwardingPlayer.playWhenReady, reason)
                }

                override fun onPlayerStateChanged(playWhenReady: Boolean, playbackState: Int) {
                    listener.onPlayerStateChanged(this@QueueForwardingPlayer.playWhenReady, this@QueueForwardingPlayer.playbackState)
                }

                override fun onPlaybackStateChanged(playbackState: Int) {
                    listener.onPlaybackStateChanged(this@QueueForwardingPlayer.playbackState)
                }

                override fun onIsPlayingChanged(isPlaying: Boolean) {
                    listener.onIsPlayingChanged(this@QueueForwardingPlayer.isPlaying)
                }

                override fun onMediaMetadataChanged(mediaMetadata: MediaMetadata) {
                    listener.onMediaMetadataChanged(this@QueueForwardingPlayer.mediaMetadata)
                }

                override fun onAvailableCommandsChanged(commands: Player.Commands) {
                    val current = this@QueueForwardingPlayer.availableCommands
                    lastCommands = current
                    listener.onAvailableCommandsChanged(current)
                }

                override fun onEvents(player: Player, events: Player.Events) {
                    refreshSessionState()
                    listener.onEvents(this@QueueForwardingPlayer, events)
                }
            }
            listenerBridges[listener] = bridge
            super.addListener(bridge)
        }

        override fun removeListener(listener: Player.Listener) {
            val bridge = listenerBridges.remove(listener) ?: return
            super.removeListener(bridge)
        }

        private fun queueHasNext(): Boolean = when (PlaybackCenter.mode) {
            Mode.VIDEO -> QueueNavigationPolicy.hasNext(PlaybackCenter.queueIndex, PlaybackCenter.queue.size)
            Mode.AUDIO -> super.hasNextMediaItem()
            Mode.NONE -> false
        }

        private fun queueHasPrevious(): Boolean = when (PlaybackCenter.mode) {
            Mode.VIDEO -> QueueNavigationPolicy.hasPrevious(PlaybackCenter.queueIndex, PlaybackCenter.queue.size)
            Mode.AUDIO -> super.hasPreviousMediaItem()
            Mode.NONE -> false
        }

        override fun isCommandAvailable(command: Int): Boolean = when (command) {
            Player.COMMAND_SEEK_TO_NEXT, Player.COMMAND_SEEK_TO_NEXT_MEDIA_ITEM -> queueHasNext()
            Player.COMMAND_SEEK_TO_PREVIOUS_MEDIA_ITEM -> queueHasPrevious()
            Player.COMMAND_SEEK_TO_PREVIOUS -> when (PlaybackCenter.mode) {
                Mode.VIDEO -> QueueNavigationPolicy.hasCurrent(PlaybackCenter.queueIndex, PlaybackCenter.queue.size)
                Mode.AUDIO -> super.isCommandAvailable(command)
                Mode.NONE -> false
            }
            else -> super.isCommandAvailable(command)
        }

        override fun getAvailableCommands(): Player.Commands {
            val commands = super.getAvailableCommands().buildUpon()
            for (command in listOf(
                Player.COMMAND_SEEK_TO_NEXT, Player.COMMAND_SEEK_TO_NEXT_MEDIA_ITEM,
                Player.COMMAND_SEEK_TO_PREVIOUS, Player.COMMAND_SEEK_TO_PREVIOUS_MEDIA_ITEM
            )) {
                if (isCommandAvailable(command)) commands.add(command) else commands.remove(command)
            }
            return commands.build()
        }

        fun refreshAvailableCommands() {
            val current = availableCommands
            if (current == lastCommands) return
            lastCommands = current
            val snapshot = listenerBridges.keys.toList()
            snapshot.forEach { it.onAvailableCommandsChanged(current) }
            val events = Player.Events(androidx.media3.common.FlagSet.Builder()
                .add(Player.EVENT_AVAILABLE_COMMANDS_CHANGED).build())
            snapshot.forEach { it.onEvents(this, events) }
        }

        override fun hasNextMediaItem(): Boolean =
            queueHasNext()

        override fun hasPreviousMediaItem(): Boolean =
            queueHasPrevious()

        override fun seekToNext() {
            PlaybackCenter.next()
        }

        override fun seekToNextMediaItem() {
            PlaybackCenter.next()
        }

        override fun seekToPrevious() {
            PlaybackCenter.previous()
        }

        override fun seekToPreviousMediaItem() {
            PlaybackCenter.previous()
        }
    }

    /** The wrapper for the currently attached PlayerView + the raw player it wraps. */
    private var forwardingPlayer: QueueForwardingPlayer? = null
    private var forwardingFor: ExoPlayer? = null
    /** ExoPlayer has one video output; only this view may own it at a time. */
    private var activePlayerView: PlayerView? = null

    @OptIn(UnstableApi::class)
    fun attachView(view: PlayerView) {
        val outputPlayer = player
        if (activePlayerView === view && view.player === outputPlayer) return
        // Rendering does not need queue-command interception/listener bridging.
        // Queue-aware notification controls continue to use sessionPlayer.
        videoFrameSeen = false
        PlayerView.switchTargetView(outputPlayer, activePlayerView, view)
        activePlayerView = view
        android.util.Log.i("PlayTubeVideo", "attach ${view.javaClass.simpleName} output=${view.videoSurfaceView?.javaClass?.simpleName}")
        startFrameWatch()
    }

    fun detachView(view: PlayerView) {
        if (activePlayerView !== view) return
        activePlayerView = null
        if (view.player === playerRef) view.player = null
        frameWatchJob?.cancel()
    }

    /** READY/isPlaying can be audio-only. Measure actual first-frame delivery on a visible output. */
    private fun startFrameWatch() {
        frameWatchJob?.cancel()
        if (mode != Mode.VIDEO || audioOnlyMode || videoFrameSeen) return
        frameWatchJob = scope.launch {
            var visibleWaitMs = 0L
            var last = SystemClock.elapsedRealtime()
            while (isActive) {
                delay(500)
                val now = SystemClock.elapsedRealtime()
                val elapsed = (now - last).coerceAtMost(1_000L)
                last = now
                val p = playerRef ?: return@launch
                val view = activePlayerView
                if (videoFrameSeen || mode != Mode.VIDEO || audioOnlyMode) return@launch
                // No recovery while backgrounded, hidden, paused, or waiting for network startup.
                if (view == null || !view.isShown || !view.isAttachedToWindow ||
                    view.windowVisibility != android.view.View.VISIBLE ||
                    !p.playWhenReady || p.playbackState != Player.STATE_READY) continue
                visibleWaitMs += elapsed
                when (VideoFramePolicy.action(visibleWaitMs, videoFrameSeen, frameRecoveryStep)) {
                    VideoFramePolicy.Action.WAIT -> Unit
                    VideoFramePolicy.Action.REBIND_OUTPUT -> {
                        frameRecoveryStep++
                        visibleWaitMs = 0L
                        android.util.Log.w("PlayTubeVideo", "No first frame: rebinding output; videoSelected=${p.currentTracks.isTypeSelected(C.TRACK_TYPE_VIDEO)} size=${p.videoSize.width}x${p.videoSize.height}")
                        // A view reference alone doesn't prove a live renderer output.
                        view.player = null
                        view.player = p
                    }
                    VideoFramePolicy.Action.RETRY_SOURCE -> {
                        frameRecoveryStep++
                        val c = catalog
                        if (c != null) {
                            android.util.Log.w("PlayTubeVideo", "No first frame after rebind: retrying progressive source")
                            dashBlocked = true
                            usedFallback = c.muxed.isNotEmpty()
                            rebuildSource(keepPosition = true)
                            return@launch
                        }
                        visibleWaitMs = 0L
                    }
                    VideoFramePolicy.Action.SHOW_ERROR -> {
                        android.util.Log.e("PlayTubeVideo", "Video output failed after bounded recovery")
                        p.pause()
                        notify { it.onError("Video could not render on this device. Tap Retry or choose a different quality.") }
                        return@launch
                    }
                }
            }
        }
    }

    fun release() {
        clearSleepTimer()
        frameWatchJob?.cancel()
        resolveJob?.cancel()
        prefetchJob?.cancel()
        watchdogJob?.cancel()
        scope.cancel()
        activePlayerView?.let { view ->
            if (view.player === playerRef) view.player = null
        }
        activePlayerView = null
        forwardingPlayer = null
        forwardingFor = null
        playerRef?.release()
        playerRef = null
    }
}

fun StreamInfoItem.toQueueEntry(isMusic: Boolean = false): QueueEntry = QueueEntry(
    url = url.orEmpty(),
    title = name.orEmpty(),
    uploader = uploaderName ?: "",
    thumbnailUrl = thumbnails.maxByOrNull { it.height }?.url.orEmpty(),
    durationSec = duration,
    isMusic = isMusic
)

fun QueueEntry.toVideoEntry(): VideoEntry = VideoEntry(
    url = url,
    title = title,
    uploader = uploader,
    thumbnailUrl = thumbnailUrl,
    durationSec = durationSec,
    isMusic = isMusic
)
